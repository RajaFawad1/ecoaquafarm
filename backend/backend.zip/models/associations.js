const Client = require('./Client/Client');
const Invoice = require('./Invoice/Invoice');
const Store = require('./Store/Store');
const Product = require('./Invoice/Product');
const ReturnInvoice = require('./Invoice/returnInvoiceModel');

const setupAssociations = (sequelize) => {
    const ClientModel = Client(sequelize);
    const InvoiceModel = Invoice(sequelize);
    const StoreModel = Store(sequelize);
    const ProductModel = Product(sequelize);
    const ReturnInvoiceModel = ReturnInvoice(sequelize);

    // Asociaciones entre Invoice y Client (Factura - Cliente)
    InvoiceModel.belongsTo(ClientModel, { foreignKey: 'clientId', as: 'client', onDelete: 'NO ACTION', onUpdate: 'CASCADE' });

    // Asociaciones entre Invoice y Store (Factura - Tienda)
    InvoiceModel.belongsTo(StoreModel, { foreignKey: 'storeId', as: 'store', onDelete: 'NO ACTION', onUpdate: 'CASCADE' });

    // Asociación entre Invoice y Product (Factura - Productos)
    InvoiceModel.hasMany(ProductModel, { foreignKey: 'invoiceId', as: 'products' });
    ProductModel.belongsTo(InvoiceModel, { foreignKey: 'invoiceId', as: 'invoice' });

    // Asociación entre ReturnInvoice y Invoice (Factura de devolución - Factura original)
    ReturnInvoiceModel.belongsTo(InvoiceModel, { foreignKey: 'originalInvoiceId', as: 'originalInvoice', onDelete: 'CASCADE', onUpdate: 'CASCADE' });

    // Asociación entre ReturnInvoice y Store (Factura de devolución - Tienda)
    ReturnInvoiceModel.belongsTo(StoreModel, { foreignKey: 'storeId', as: 'store', onDelete: 'CASCADE', onUpdate: 'CASCADE' });

    // Si necesitas que un ReturnInvoice pueda tener productos, se puede agregar una asociación adicional
    // ReturnInvoiceModel.hasMany(ProductModel, { foreignKey: 'returnInvoiceId', as: 'returnProducts' });

    return {
        Client: ClientModel,
        Invoice: InvoiceModel,
        Store: StoreModel,
        Product: ProductModel,
        ReturnInvoice: ReturnInvoiceModel,
    };
};

module.exports = setupAssociations;
