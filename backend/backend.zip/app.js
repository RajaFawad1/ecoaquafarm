require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();
const { sequelize } = require("./models");
const clientRoutes = require("./routes/clientRoutes");
const invoiceRoutes = require("./routes/invoiceRoutes");
const storeRoutes = require("./routes/storeRoutes");
const returnsRoutes = require("./routes/returnInvoiceRoutes");

// Configuración de CORS
const corsOptions = {
    origin: "http://localhost:3000", // Permite solicitudes desde el frontend
    methods: ["GET", "POST", "PUT", "DELETE"], // Métodos HTTP permitidos
    allowedHeaders: ["Content-Type", "Authorization"], // Headers permitidos
};

app.use(cors(corsOptions));

// Middleware para parsear JSON
app.use(express.json());

// Ruta principal para verificar que el backend está funcionando
app.get("/", (req, res) => {
    res.send("¡El backend está funcionando correctamente!");
});

// Rutas específicas (CORREGIDO)
app.use("/api/clients", clientRoutes);
app.use("/api/invoices", invoiceRoutes);
app.use("/api/stores", storeRoutes);
app.use("/api/returns", returnsRoutes);

// Sincronización y arranque
const PORT = process.env.PORT || 3001;

sequelize.sync({ alter: true }).then(() => {
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
});
