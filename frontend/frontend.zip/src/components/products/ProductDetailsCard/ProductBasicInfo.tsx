'use client';

import React from 'react';
import { Box, Typography, Divider } from '@mui/material';
import FileUploadSelectCard from './CardsDonwload/FileUploadSelectCard';

interface ProductBasicInfoProps {
    nombreProducto: string;
    SKU: string;
    ASIN: string;
    tituloAmazon: string;
    marca: string;
    categoria: string;
    createdAt?: string;
    updatedAt?: string;
}

const ProductBasicInfo: React.FC<ProductBasicInfoProps> = ({
    nombreProducto,
    SKU,
    ASIN,
    tituloAmazon,
    marca,
    categoria,
    createdAt,
}) => {
    const formattedDate = createdAt ? new Date(createdAt).toLocaleDateString() : 'N/A';

    return (
        <Box
            sx={{
                p: 3,
                backgroundColor: '#ffffff',
                borderRadius: 3,
                boxShadow: 3,
                mb: 3,
            }}
        >
            <Box sx={{ display: 'flex', gap: 2 }}>
                {/* Columna Izquierda: Información Básica (80%) */}
                <Box sx={{ flex: 8 }}>
                    <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: '#333' }}>
                        {nombreProducto}
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                    <Typography variant="subtitle1" color="text.secondary" sx={{ mb: 1 }}>
                        <strong>SKU:</strong> {SKU} | <strong>ASIN:</strong> {ASIN}
                    </Typography>
                    <Typography variant="body1" sx={{ mb: 2, color: '#555' }}>
                        <strong>Título para Amazon:</strong> {tituloAmazon}
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 2 }}>
                        <Typography variant="body2" color="text.secondary">
                            <strong>Marca:</strong> {marca}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            <strong>Categoría:</strong> {categoria}
                        </Typography>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                        Publicado el: {formattedDate}
                    </Typography>
                </Box>
                {/* Columna Derecha: Formulario de Subida de Archivo (20%) */}
                <Box sx={{ flex: 2 }}>
                    <FileUploadSelectCard sku={SKU} />
                </Box>
            </Box>
        </Box>
    );
};

export default ProductBasicInfo;
