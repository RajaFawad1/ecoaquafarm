'use client';

import React from 'react';
import { Card, CardContent, Box, Grid } from '@mui/material';
import ProductBasicInfo from './ProductBasicInfo';
import ProductImageSection from './ProductImageSection';
import ProductDimensions from './ProductDimensions';
import PackageDimensions from './PackageDimensions';
import CertificadosCard from './CardsDonwload/CertificadosCard';
import PegatinasCard from './CardsDonwload/PegatinasCard';
import ManualesCard from './CardsDonwload/ManualesCard';
import DeclaracionConformidadCard from './CardsDonwload/DeclaracionConformidadCard';
import OthersCard from './CardsDonwload/OthersCard';

interface Product {
    SKU: string;
    ASIN: string;
    nombreProducto: string;
    tituloAmazon: string;
    marca: string;
    categoria: string;
    imagenPrincipal?: string;
    imagenes?: string | string[];
    dimensionesProducto?: {
        longitudProducto?: number;
        anchoProducto?: number;
        alturaProducto?: number;
        pesoNeto?: number;
    };
    dimensionesPaquete?: {
        longitudPaquete?: number;
        anchoPaquete?: number;
        alturaPaquete?: number;
        pesoBruto?: number;
        tipoEmbalaje?: string;
        cantidadPiezas?: number;
        unidadMedida?: string;
    };
    archivosSKU?: any[];
    certificados?: any[];
    pegatinas?: any[];
    manuales?: any[];
    declaraciones?: any[];
    otros?: any[];
    createdAt?: string;
}

interface ProductDetailCardProps {
    product: Product;
}

const baseURL = process.env.NEXT_PUBLIC_API_BASE_URL || '';

const ProductDetailCard: React.FC<ProductDetailCardProps> = ({ product }) => {
    // Si los archivos no están filtrados por tipo en el backend,
    // se puede transformar aquí a partir de product.archivosSKU
    const archivos = product.archivosSKU || [];

    // Filtrar por tipo de archivo
    const certificados = archivos.filter(file => file.type === "certificado");
    const pegatinas = archivos.filter(file => file.type === "pegatina");
    const manuales = archivos.filter(file => file.type === "manual");
    // Puedes ajustar el filtro para declaraciones según como se almacene el type
    const declaraciones = archivos.filter(file => file.type === "declaracion" || file.type === "declaracionConformidad");
    // El resto de archivos se considerarán "otros"
    const otros = archivos.filter(file =>
        file.type !== "certificado" &&
        file.type !== "pegatina" &&
        file.type !== "manual" &&
        file.type !== "declaracion" &&
        file.type !== "declaracionConformidad"
    );

    return (
        <Card variant="outlined" sx={{ padding: 2 }}>
            <CardContent>
                <Box id="pdf-content">
                    {/* Información Básica */}
                    <ProductBasicInfo
                        nombreProducto={product.nombreProducto}
                        SKU={product.SKU}
                        ASIN={product.ASIN}
                        tituloAmazon={product.tituloAmazon}
                        marca={product.marca}
                        categoria={product.categoria}
                        createdAt={product.createdAt}
                    />
                    <Grid container spacing={3}>
                        <Box
                            sx={{
                                display: 'grid',
                                gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(5, 1fr)' },
                                gap: 3,
                                mt: 4,
                            }}
                        >
                            <CertificadosCard certificados={certificados} sku={product.SKU} />
                            <PegatinasCard pegatinas={pegatinas} sku={product.SKU} />
                            <ManualesCard manuales={manuales} sku={product.SKU} />
                            <DeclaracionConformidadCard declaraciones={declaraciones} sku={product.SKU} />
                            <OthersCard otros={otros} sku={product.SKU} />
                        </Box>
                    </Grid>
                    {/* Sección de Imágenes */}
                    <ProductImageSection
                        imagenPrincipal={product.imagenPrincipal}
                        imagenes={product.imagenes}
                        baseURL={baseURL}
                    />
                    {/* Dimensiones */}
                    {product.dimensionesProducto && (
                        <ProductDimensions dimensionesProducto={product.dimensionesProducto} />
                    )}
                    {product.dimensionesPaquete && (
                        <PackageDimensions dimensionesPaquete={product.dimensionesPaquete} />
                    )}
                </Box>
            </CardContent>
        </Card>
    );
};

export default ProductDetailCard;
