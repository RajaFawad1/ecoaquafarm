'use client';

import React from 'react';
import { Box, Typography, Grid } from '@mui/material';

interface PackageDimensionsProps {
    dimensionesPaquete: {
        longitudPaquete?: number;
        anchoPaquete?: number;
        alturaPaquete?: number;
        pesoBruto?: number;
        tipoEmbalaje?: string;
        cantidadPiezas?: number;
        unidadMedida?: string;
    };
}

const PackageDimensions: React.FC<PackageDimensionsProps> = ({ dimensionesPaquete }) => {
    return (
        <Box mt={3} p={2} sx={{ border: '1px solid #e0e0e0', borderRadius: 2, boxShadow: 1 }}>
            <Typography variant="h6" gutterBottom>
                Dimensiones del Paquete
            </Typography>
            <Grid container spacing={2}>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Longitud
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.longitudPaquete ?? 'N/A'} cm
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Medida de la parte más larga del paquete.
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Ancho
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.anchoPaquete ?? 'N/A'} cm
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Medida de la parte más ancha del paquete.
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Altura
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.alturaPaquete ?? 'N/A'} cm
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Medida de la altura del paquete.
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Peso Bruto
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.pesoBruto ?? 'N/A'} kg
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Peso total del paquete (incluye embalaje).
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Tipo de Embalaje
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.tipoEmbalaje || 'N/A'}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Descripción del tipo de embalaje.
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Cantidad de Piezas
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.cantidadPiezas ?? 'N/A'}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Número de piezas en el paquete.
                    </Typography>
                </Grid>
                <Grid item xs={6}>
                    <Typography variant="subtitle2" color="textPrimary">
                        Unidad de Medida
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                        {dimensionesPaquete.unidadMedida || 'N/A'}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                        Unidad utilizada para las dimensiones.
                    </Typography>
                </Grid>
            </Grid>
        </Box>
    );
};

export default PackageDimensions;
