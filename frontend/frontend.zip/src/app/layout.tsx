'use client';

import React from 'react';
import Link from 'next/link';
import { Box } from '@mui/material';
import SidebarMenu from '../components/SidebarMenu';

const Layout = ({ children }: { children: React.ReactNode }) => {
    return (
        <html lang="en">
            <head>
                <title>Panel de Gestión</title>
            </head>
            <body>
                <Box sx={{ display: 'flex' }}>
                    <SidebarMenu />
                    <Box sx={{ marginLeft: '250px', padding: '20px', width: '100%' }}>
                        <nav style={{ padding: '10px', backgroundColor: '#f4f4f4' }}>
                            <Link href="/">🏠 Inicio</Link>
                        </nav>
                        {children}
                    </Box>
                </Box>
            </body>
        </html>
    );
};

export default Layout;
