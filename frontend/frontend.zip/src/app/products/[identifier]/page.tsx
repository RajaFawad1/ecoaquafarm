// pages/ProductDetailPage.tsx
'use client';

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import apiClient from '@/utils/apiClient';
import { Box, Typography, CircularProgress, Button } from '@mui/material';
import ErrorMessage from '@/components/ErrorMessage';
import ProductDetailCard from '@/components/products/ProductDetailsCard/ProductDetailCard';
import ProductAmazonContentDetail from '@/components/products/ProductDetailsCard/ProductAmazonContentDetail';
import DimensionesPackKit from '@/components/products/ProductDetailsCard/DimensionesPackKit';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface Product {
    SKU: string;
    ASIN: string;
    nombreProducto: string;
    tituloAmazon: string;
    marca: string;
    categoria: string;
    // ...otros campos
    dimensionesPackKit?: {
        packKit: string;
        cantidadProductos?: number;
        largo?: number;
        ancho?: number;
        alto?: number;
        pesoBrutoPack?: number;
        precioVentaPack?: number | null;
        observaciones: string;
        ASIN: string;
    };
    contenidoAmazon?: {
        descripcion: string;
        bullet1: string;
        bullet2: string;
        bullet3: string;
        bullet4: string;
        bullet5: string;
        bullet6: string;
        bullet7: string;
    };
}

const ProductDetailPage = () => {
    const { identifier } = useParams();
    const [product, setProduct] = useState<Product | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [pdfGenerating, setPdfGenerating] = useState(false);

    const fetchProduct = async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await apiClient.get(`/products/${identifier}`);
            setProduct(response.data);
        } catch (error) {
            console.error('Error fetching product details:', error);
            setError('No se pudo cargar el detalle del producto. Inténtalo más tarde.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (identifier) {
            fetchProduct();
        }
    }, [identifier, fetchProduct]);

    const handleDownloadPDF = async () => {
        const detailsEl = document.getElementById('pdf-content-details');
        const contentEl = document.getElementById('pdf-content-page2');
        if (!detailsEl || !contentEl) {
            console.error('No se encontraron los elementos necesarios para el PDF');
            return;
        }
        setPdfGenerating(true);
        try {
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();

            // Capturar la primera sección (detalles generales)
            const canvasDetails = await html2canvas(detailsEl, {
                scale: 2,
                useCORS: true,
                allowTaint: false,
            });
            const imgDataDetails = canvasDetails.toDataURL('image/png');
            const pdfHeightDetails = (canvasDetails.height * pdfWidth) / canvasDetails.width;
            pdf.addImage(imgDataDetails, 'PNG', 0, 0, pdfWidth, pdfHeightDetails);

            // Añadir una nueva página para el contenido adicional (pack/kit y contenido Amazon)
            pdf.addPage();
            const canvasContent = await html2canvas(contentEl, {
                scale: 2,
                useCORS: true,
                allowTaint: false,
            });
            const imgDataContent = canvasContent.toDataURL('image/png');
            const pdfHeightContent = (canvasContent.height * pdfWidth) / canvasContent.width;
            pdf.addImage(imgDataContent, 'PNG', 0, 0, pdfWidth, pdfHeightContent);

            pdf.save(`${product?.nombreProducto || 'detalle_producto'}.pdf`);
        } catch (error) {
            console.error('Error al generar el PDF:', error);
        } finally {
            setPdfGenerating(false);
        }
    };

    if (loading) return <CircularProgress />;
    if (error) return <ErrorMessage message={error} />;
    if (!product) return <Typography variant="h6">Producto no encontrado</Typography>;

    return (
        <Box sx={{ padding: 4, position: 'relative' }}>
            <Typography variant="h4" gutterBottom>
                Detalle del Producto
            </Typography>
            <Button variant="contained" color="primary" onClick={handleDownloadPDF} sx={{ mb: 3 }}>
                Descargar PDF
            </Button>
            <Box>
                {/* Primera sección: Detalles generales del producto */}
                <Box id="pdf-content-details">
                    <ProductDetailCard product={product} />
                </Box>
                {/* Segunda sección: Dimensiones del Pack/Kit y Contenido para Amazon */}
                <Box id="pdf-content-page2" sx={{ mt: 4 }}>
                    {product.dimensionesPackKit && (
                        <DimensionesPackKit dimensionesPackKit={product.dimensionesPackKit} />
                    )}
                    {product.contenidoAmazon && (
                        <ProductAmazonContentDetail
                            descripcion={product.contenidoAmazon.descripcion}
                            bullet1={product.contenidoAmazon.bullet1}
                            bullet2={product.contenidoAmazon.bullet2}
                            bullet3={product.contenidoAmazon.bullet3}
                            bullet4={product.contenidoAmazon.bullet4}
                            bullet5={product.contenidoAmazon.bullet5}
                            bullet6={product.contenidoAmazon.bullet6}
                            bullet7={product.contenidoAmazon.bullet7}
                        />
                    )}
                </Box>
            </Box>
            {/* Overlay de generación del PDF */}
            {pdfGenerating && (
                <Box
                    sx={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100vw',
                        height: '100vh',
                        backgroundColor: 'rgba(255, 255, 255, 0.8)',
                        backdropFilter: 'blur(5px)',
                        zIndex: 9999,
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        alignItems: 'center',
                        color: '#333',
                        textAlign: 'center',
                        p: 2,
                    }}
                >
                    <CircularProgress size={80} sx={{ mb: 2 }} />
                    <Typography variant="h6">
                        Generando PDF... ⏳
                    </Typography>
                </Box>
            )}
        </Box>
    );
};

export default ProductDetailPage;
