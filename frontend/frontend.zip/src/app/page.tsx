'use client';

import Image from "next/image";
import Link from "next/link";
import { Box, Typography, Button, Card, CardContent, CardActions, useTheme, useMediaQuery } from "@mui/material";

export default function Home() {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Box
      sx={{
        width: "90vw",
        height: "90vh",
        mx: "auto",
        my: "auto",
        backgroundColor: "white",
        borderRadius: 2,
        boxShadow: 3,
        display: "flex",
        flexDirection: "column",
      }}
    >


      {/* Contenido principal */}
      <Box
        sx={{
          flexGrow: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          p: 4,
        }}
      >
        <Card sx={{ width: "100%", maxWidth: "800px", borderRadius: 2, boxShadow: 2 }}>
          <CardContent sx={{ textAlign: "center" }}>
            <Typography variant="h4" gutterBottom>
              🌊 Panel de Ventas de Bombas de Agua 🚀
            </Typography>
            <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
              <Image
                src="/pump-illustration.png"
                alt="Bomba de agua"
                width={200}
                height={150}
                priority
              />
            </Box>
            <Typography variant="body1" gutterBottom>
              Gestiona tus productos de forma sencilla, controla tu inventario y mejora la experiencia de venta.
            </Typography>
          </CardContent>
          <CardActions sx={{ justifyContent: "center", pb: 2 }}>
            <Link href="/products" passHref legacyBehavior>
              <Button variant="contained" color="primary" sx={{ mx: 1, borderRadius: 2 }}>
                🛍️ Ver Productos
              </Button>
            </Link>
            <Link href="/orders" passHref legacyBehavior>
              <Button variant="contained" color="secondary" sx={{ mx: 1, borderRadius: 2 }}>
                📦 Gestionar Pedidos
              </Button>
            </Link>
            <Link href="/amazon" passHref legacyBehavior>
              <Button variant="outlined" color="inherit" sx={{ mx: 1, borderRadius: 2 }}>
                🛒 Ver en Amazon
              </Button>
            </Link>
          </CardActions>
        </Card>
      </Box>

      {/* Pie de página */}
      <Box sx={{ p: 2, textAlign: "center", borderTop: "1px solid #ddd" }}>
        <Typography variant="body2">
          Powered by <strong>EAF Store</strong> 🌍 | Agua en movimiento 💧
        </Typography>
      </Box>
    </Box>
  );
}
